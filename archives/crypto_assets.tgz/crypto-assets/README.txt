crypto-assets bundle (synthetic)
correct-crypto/       = correctly-used real crypto -> detect (true positives)
quantum-vulnerable/   = Shor-breakable real algorithms -> detect
quantum-resistant/    = post-quantum real algorithms -> detect
false-positives/      = lookalike decoys -> expect ZERO findings
